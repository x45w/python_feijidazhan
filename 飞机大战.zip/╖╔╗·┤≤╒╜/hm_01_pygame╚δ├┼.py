import pygame
pygame.init()

print("游戏的代码...")

pygame.quit()